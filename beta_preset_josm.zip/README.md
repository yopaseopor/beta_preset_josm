[![Build Status](https://travis-ci.org/yopaseopor/traffic_signs_preset_JOSM.svg?branch=master)](https://travis-ci.org/yopaseopor/traffic_signs_preset_JOSM)
# traffic_signs_preset_JOSM
Traffic signs Preset for JOSM



